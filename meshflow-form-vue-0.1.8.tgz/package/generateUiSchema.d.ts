import { UISchemaElement } from '@jsonforms/core';
import { MeshFormSchema } from '../forms/jsonforms/types';
export declare function generateUiSchema(schema: MeshFormSchema): UISchemaElement;
