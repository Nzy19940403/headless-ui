import { defineComponent as V, inject as B, computed as C, resolveComponent as F, openBlock as y, createElementBlock as k, createBlock as M, createCommentVNode as P, unref as s, createElementVNode as J, toDisplayString as Y, createVNode as U, normalizeClass as Q, Fragment as L, renderList as q, normalizeStyle as Z, markRaw as $, ref as W, shallowRef as ee, provide as te, onMounted as re, onUnmounted as le, renderSlot as oe } from "vue";
import { useJsonFormsControl as ne, rendererProps as K, useJsonFormsLayout as ae, DispatchRenderer as E, JsonForms as se } from "@jsonforms/vue";
import { schemaMatches as ue, rankWith as S, isStringControl as ie, isNumberControl as de, isIntegerControl as ce, isBooleanControl as pe, or as me, isEnumControl as he, uiTypeIs as N } from "@jsonforms/core";
import { useMeshFormJson as ve, deleteEngine as ye } from "@meshflow/form";
import { deleteEngine as Ie, from as Te } from "@meshflow/form";
const z = Symbol("meshNodeMap"), be = {
  key: 0,
  class: "mesh-control"
}, fe = /* @__PURE__ */ V({
  __name: "MeshControlRenderer",
  props: { ...K() },
  setup(a) {
    const b = a, { control: t } = ne(b), n = B(z), c = C(() => {
      var e;
      return (e = n == null ? void 0 : n.value) == null ? void 0 : e[t.value.path];
    }), r = C(() => {
      var m, f;
      (f = (m = c.value) == null ? void 0 : m.dirtySignal) == null || f.value;
      const e = c.value, l = t.value.schema;
      let o = "input";
      const u = e == null ? void 0 : e.type;
      u === "select" || u === "checkbox" || u === "number" ? o = u : (l == null ? void 0 : l.type) === "boolean" ? o = "checkbox" : ((l == null ? void 0 : l.type) === "number" || (l == null ? void 0 : l.type) === "integer") && (o = "number");
      const p = (e == null ? void 0 : e.options) ?? ((l == null ? void 0 : l.enum) ?? []).map((_) => ({ label: String(_), value: _ })) ?? [];
      return p.length > 0 && (o = "select"), {
        widgetType: o,
        value: e != null ? e.value : (l == null ? void 0 : l.default) ?? "",
        disabled: !!(e != null && e.disabled),
        readonly: !!(e != null && e.readonly),
        hidden: !!(e != null && e.hidden),
        required: !!(e != null && e.required),
        label: (e == null ? void 0 : e.label) ?? t.value.label ?? t.value.path,
        placeholder: (e == null ? void 0 : e.placeholder) ?? (l == null ? void 0 : l["x-placeholder"]) ?? "",
        theme: (e == null ? void 0 : e.theme) ?? (l == null ? void 0 : l["x-theme"]),
        options: p,
        min: (e == null ? void 0 : e.min) ?? (l == null ? void 0 : l["x-min"]),
        maxLength: (e == null ? void 0 : e.maxLength) ?? (l == null ? void 0 : l["x-maxLength"])
      };
    });
    function i(e) {
      var l, o;
      (o = (l = c.value) == null ? void 0 : l.dependOn) == null || o.call(l, () => e, "value");
    }
    return (e, l) => {
      const o = F("v-select"), u = F("v-checkbox"), p = F("v-text-field");
      return r.value.hidden ? P("", !0) : (y(), k("div", be, [
        r.value.widgetType === "select" ? (y(), M(o, {
          key: 0,
          "model-value": r.value.value,
          items: r.value.options,
          "item-title": "label",
          "item-value": "value",
          label: r.value.label,
          disabled: r.value.disabled,
          readonly: r.value.readonly,
          required: r.value.required,
          placeholder: r.value.placeholder,
          color: r.value.theme,
          density: "comfortable",
          variant: "outlined",
          "onUpdate:modelValue": i
        }, null, 8, ["model-value", "items", "label", "disabled", "readonly", "required", "placeholder", "color"])) : r.value.widgetType === "checkbox" ? (y(), M(u, {
          key: 1,
          "model-value": r.value.value,
          label: r.value.label,
          disabled: r.value.disabled,
          readonly: r.value.readonly,
          color: r.value.theme ?? "primary",
          density: "comfortable",
          "onUpdate:modelValue": i
        }, null, 8, ["model-value", "label", "disabled", "readonly", "color"])) : r.value.widgetType === "number" ? (y(), M(p, {
          key: 2,
          "model-value": r.value.value,
          type: "number",
          label: r.value.label,
          disabled: r.value.disabled,
          readonly: r.value.readonly,
          required: r.value.required,
          placeholder: r.value.placeholder,
          color: r.value.theme,
          min: r.value.min,
          density: "comfortable",
          variant: "outlined",
          "onUpdate:modelValue": l[0] || (l[0] = (m) => i(m === "" ? null : Number(m)))
        }, null, 8, ["model-value", "label", "disabled", "readonly", "required", "placeholder", "color", "min"])) : (y(), M(p, {
          key: 3,
          "model-value": r.value.value,
          label: r.value.label,
          disabled: r.value.disabled,
          readonly: r.value.readonly,
          required: r.value.required,
          placeholder: r.value.placeholder,
          color: r.value.theme,
          maxlength: r.value.maxLength,
          density: "comfortable",
          variant: "outlined",
          "onUpdate:modelValue": i
        }, null, 8, ["model-value", "label", "disabled", "readonly", "required", "placeholder", "color", "maxlength"]))
      ]));
    };
  }
}), R = (a, b) => {
  const t = a.__vccOpts || a;
  for (const [n, c] of b)
    t[n] = c;
  return t;
}, O = /* @__PURE__ */ R(fe, [["__scopeId", "data-v-8b010d3f"]]), _e = {
  key: 0,
  class: "mesh-group"
}, ge = {
  key: 0,
  class: "mesh-group__header"
}, xe = { class: "mesh-group__title" }, ke = {
  key: 1,
  class: "mesh-layout mesh-layout--horizontal"
}, Ce = {
  key: 2,
  class: "mesh-layout mesh-layout--vertical"
}, $e = /* @__PURE__ */ V({
  __name: "MeshGroupRenderer",
  props: { ...K() },
  setup(a) {
    const b = a, { layout: t } = ae(b), n = B(z), c = C(() => {
      var u;
      const o = t.value.uischema;
      return (o == null ? void 0 : o.label) || ((u = o == null ? void 0 : o.options) == null ? void 0 : u.label) || null;
    }), r = C(() => {
      var m, f;
      const o = (f = (m = t.value.uischema) == null ? void 0 : m.options) == null ? void 0 : f.nodePath;
      if (!o) return [];
      const u = (n == null ? void 0 : n.value) ?? {}, p = o + ".";
      return Object.entries(u).filter(([_]) => _.startsWith(p) && !_.slice(p.length).includes(".")).map(([, _]) => _);
    }), i = C(() => {
      const o = r.value;
      return o.length ? (o.forEach((u) => {
        var p;
        return (p = u == null ? void 0 : u.dirtySignal) == null ? void 0 : p.value;
      }), o.every((u) => (u == null ? void 0 : u.hidden) === !0)) : !1;
    }), e = C(() => {
      var p;
      const o = t.value.uischema;
      return (((p = o == null ? void 0 : o.options) == null ? void 0 : p["x-layout"]) ?? "vertical") === "horizontal" ? "mesh-group__body--horizontal" : "mesh-group__body--vertical";
    });
    function l(o) {
      var m;
      const u = ((m = o == null ? void 0 : o.options) == null ? void 0 : m.span) ?? 1, p = u * 180;
      return { flex: `${u} 1 ${p}px` };
    }
    return (o, u) => {
      const p = F("v-divider");
      return s(t).uischema.type === "Group" && !i.value ? (y(), k("div", _e, [
        c.value ? (y(), k("div", ge, [
          J("span", xe, Y(c.value), 1),
          U(p, { class: "mesh-group__divider" })
        ])) : P("", !0),
        J("div", {
          class: Q(["mesh-group__body", e.value])
        }, [
          (y(!0), k(L, null, q(s(t).uischema.elements, (m, f) => (y(), M(s(E), {
            key: `${s(t).path}-${f}`,
            schema: s(t).schema,
            uischema: m,
            path: s(t).path,
            enabled: s(t).enabled,
            renderers: s(t).renderers,
            cells: s(t).cells
          }, null, 8, ["schema", "uischema", "path", "enabled", "renderers", "cells"]))), 128))
        ], 2)
      ])) : s(t).uischema.type === "HorizontalLayout" ? (y(), k("div", ke, [
        (y(!0), k(L, null, q(s(t).uischema.elements, (m, f) => (y(), k("div", {
          key: `${s(t).path}-${f}`,
          class: "mesh-layout__item",
          style: Z(l(m))
        }, [
          U(s(E), {
            schema: s(t).schema,
            uischema: m,
            path: s(t).path,
            enabled: s(t).enabled,
            renderers: s(t).renderers,
            cells: s(t).cells
          }, null, 8, ["schema", "uischema", "path", "enabled", "renderers", "cells"])
        ], 4))), 128))
      ])) : (y(), k("div", Ce, [
        (y(!0), k(L, null, q(s(t).uischema.elements, (m, f) => (y(), M(s(E), {
          key: `${s(t).path}-${f}`,
          schema: s(t).schema,
          uischema: m,
          path: s(t).path,
          enabled: s(t).enabled,
          renderers: s(t).renderers,
          cells: s(t).cells
        }, null, 8, ["schema", "uischema", "path", "enabled", "renderers", "cells"]))), 128))
      ]));
    };
  }
}), j = /* @__PURE__ */ R($e, [["__scopeId", "data-v-ef8cbc6d"]]), Se = ue(
  (a) => Array.isArray(a == null ? void 0 : a["x-options"]) && a["x-options"].length > 0
), H = [
  // ── Leaf field controls ──────────────────────────────────────────────────
  { tester: S(3, ie), renderer: $(O) },
  { tester: S(3, de), renderer: $(O) },
  { tester: S(3, ce), renderer: $(O) },
  { tester: S(3, pe), renderer: $(O) },
  // Select: enum OR x-options (higher priority than plain string)
  { tester: S(5, me(he, Se)), renderer: $(O) },
  // ── Layout / Group elements ──────────────────────────────────────────────
  { tester: S(2, N("VerticalLayout")), renderer: $(j) },
  { tester: S(2, N("HorizontalLayout")), renderer: $(j) },
  { tester: S(2, N("Group")), renderer: $(j) }
];
function X(a) {
  return a.type === "object";
}
function Me(a, b) {
  return (a["x-order"] ?? Object.keys(a.properties)).map((n) => {
    const c = a.properties[n];
    if (!c) return null;
    if (X(c)) {
      const r = `${b}/${n}/properties`, i = Oe(c, r), e = c["x-layout"] === "horizontal" ? [{ type: "HorizontalLayout", elements: i }] : i;
      return {
        type: "Group",
        label: c.title ?? n,
        elements: e
      };
    }
    return { type: "Control", scope: `${b}/${n}` };
  }).filter((n) => n !== null);
}
function Oe(a, b) {
  return (a["x-order"] ?? Object.keys(a.properties)).map((n) => {
    const c = a.properties[n];
    return !c || X(c) ? null : { type: "Control", scope: `${b}/${n}` };
  }).filter((n) => n !== null);
}
function Fe(a) {
  return {
    type: "VerticalLayout",
    elements: Me(a, "#/properties")
  };
}
function Le(a, b, t) {
  return ve(a, b, {
    ...t,
    UITrigger: {
      signalCreator: () => W(0),
      signalTrigger: (c) => {
        c.value++;
      }
    }
  });
}
const qe = {
  key: 1,
  class: "mesh-form"
}, Ee = /* @__PURE__ */ V({
  __name: "MeshForm",
  props: {
    schema: {},
    data: {},
    rules: {},
    uischema: {},
    renderers: {}
  },
  emits: ["submit", "change"],
  setup(a, { expose: b, emit: t }) {
    var I, T, w, A;
    const n = a, c = t, r = crypto.randomUUID(), i = Le(r, n.schema);
    n.rules && i.define(n.rules), i.hooks.onSuccess(() => {
      c("change", JSON.parse(JSON.stringify(_())));
    });
    function e(d, h = {}) {
      if (!d) return h;
      d.path != null && d.path !== "" && (h[d.path] = d);
      for (const v of d.children ?? []) e(v, h);
      return h;
    }
    function l(d, h = "") {
      const v = {};
      for (const [g, x] of Object.entries(d)) {
        const G = h ? `${h}.${g}` : g;
        x != null && typeof x == "object" && !Array.isArray(x) ? Object.assign(v, l(x, G)) : v[G] = x;
      }
      return v;
    }
    if (n.data) {
      const d = (w = (T = (I = i == null ? void 0 : i.modules) == null ? void 0 : I.internalModules) == null ? void 0 : T.internalForm) == null ? void 0 : w.uiSchema, h = d ? e(d) : {};
      for (const [v, g] of Object.entries(l(n.data))) {
        const x = h[v];
        x && g !== void 0 && ((A = x.dependOn) == null || A.call(x, () => g, "value"));
      }
    }
    const o = W(!1), u = ee({}), p = C(
      () => n.uischema ?? Fe(n.schema)
    ), m = C(
      () => n.renderers ? [...n.renderers, ...H] : H
    ), f = C(() => {
      var h, v, g;
      const d = (g = (v = (h = i == null ? void 0 : i.modules) == null ? void 0 : h.internalModules) == null ? void 0 : v.internalForm) == null ? void 0 : g.uiSchema;
      return d ? e(d) : {};
    });
    te(z, f);
    function _() {
      var d, h, v, g;
      return ((g = (v = (h = (d = i == null ? void 0 : i.modules) == null ? void 0 : d.internalModules) == null ? void 0 : h.internalForm) == null ? void 0 : v.GetFormData) == null ? void 0 : g.call(v)) ?? {};
    }
    async function D() {
      c("submit", _());
    }
    return re(() => {
      var d, h;
      (h = (d = i == null ? void 0 : i.config) == null ? void 0 : d.notifyAll) == null || h.call(d), o.value = !0;
    }), le(() => {
      try {
        ye(r);
      } catch {
      }
    }), b({ engine: i, submit: D, getFormData: _ }), (d, h) => {
      const v = F("v-skeleton-loader");
      return o.value ? (y(), k("div", qe, [
        U(s(se), {
          schema: n.schema,
          uischema: p.value,
          data: u.value,
          renderers: m.value,
          onChange: () => {
          }
        }, null, 8, ["schema", "uischema", "data", "renderers"]),
        oe(d.$slots, "actions", {
          submit: D,
          getFormData: _
        }, void 0, !0)
      ])) : (y(), M(v, {
        key: 0,
        type: "article, actions"
      }));
    };
  }
}), ze = /* @__PURE__ */ R(Ee, [["__scopeId", "data-v-e7052c49"]]);
export {
  z as MESH_NODE_MAP_KEY,
  ze as MeshForm,
  Ie as deleteEngine,
  Te as from,
  H as meshRenderers,
  Le as useMeshFormVue
};
