declare const _default: import('vue').DefineComponent<import('vue').ExtractPropTypes<{
    schema: {
        required: true;
        type: import('vue').PropType<import('@jsonforms/core').JsonSchema>;
    };
    uischema: {
        required: true;
        type: import('vue').PropType<import('@jsonforms/core').UISchemaElement>;
    };
    path: {
        required: true;
        type: StringConstructor;
    };
    enabled: {
        required: false;
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        required: false;
        type: BooleanConstructor;
        default: undefined;
    };
    renderers: {
        required: boolean;
        type: import('vue').PropType<import('@jsonforms/core').JsonFormsRendererRegistryEntry[]>;
        default: undefined;
    };
    cells: {
        required: boolean;
        type: import('vue').PropType<import('@jsonforms/core').JsonFormsCellRendererRegistryEntry[]>;
        default: undefined;
    };
    config: {
        required: boolean;
        type: ObjectConstructor;
        default: undefined;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<import('vue').ExtractPropTypes<{
    schema: {
        required: true;
        type: import('vue').PropType<import('@jsonforms/core').JsonSchema>;
    };
    uischema: {
        required: true;
        type: import('vue').PropType<import('@jsonforms/core').UISchemaElement>;
    };
    path: {
        required: true;
        type: StringConstructor;
    };
    enabled: {
        required: false;
        type: BooleanConstructor;
        default: undefined;
    };
    readonly: {
        required: false;
        type: BooleanConstructor;
        default: undefined;
    };
    renderers: {
        required: boolean;
        type: import('vue').PropType<import('@jsonforms/core').JsonFormsRendererRegistryEntry[]>;
        default: undefined;
    };
    cells: {
        required: boolean;
        type: import('vue').PropType<import('@jsonforms/core').JsonFormsCellRendererRegistryEntry[]>;
        default: undefined;
    };
    config: {
        required: boolean;
        type: ObjectConstructor;
        default: undefined;
    };
}>> & Readonly<{}>, {
    readonly: boolean;
    config: Record<string, any>;
    enabled: boolean;
    renderers: import('@jsonforms/core').JsonFormsRendererRegistryEntry[];
    cells: import('@jsonforms/core').JsonFormsCellRendererRegistryEntry[];
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>;
export default _default;
