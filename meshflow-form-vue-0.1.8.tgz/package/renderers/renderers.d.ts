import { JsonFormsRendererRegistryEntry } from '@jsonforms/core';
export declare const meshRenderers: JsonFormsRendererRegistryEntry[];
