import { deleteEngine, from, MeshFormSchema, FromDescriptor, MeshGraph } from '@meshflow/form';
type NodeProp = 'value' | 'hidden' | 'disabled' | 'readonly' | 'required' | 'options' | 'placeholder' | 'label' | 'theme';
type JsonLeafPaths<T, Prefix extends string = ''> = T extends {
    type: 'object';
    properties: infer P;
} ? string extends keyof P ? Prefix extends '' ? string : `${Prefix}.${string}` : P extends Record<string, any> ? {
    [K in keyof P & string]: JsonLeafPaths<P[K], Prefix extends '' ? K : `${Prefix}.${K}`>;
}[keyof P & string] : never : Prefix;
type MeshDefineRules<S extends MeshFormSchema> = string extends keyof S['properties'] ? Record<string, FromDescriptor> : Partial<Record<`${JsonLeafPaths<S>}.${NodeProp}`, FromDescriptor>>;
export declare function useMeshFormVue<S extends MeshFormSchema, M extends Record<string, any> = {}>(id: string, schema: S, options?: {
    modules?: M;
    config?: {
        useGreedy?: boolean;
    };
}): Omit<import('@meshflow/core').BaseEngine<import('@meshflow/core').SchedulerType<import('vue').Ref<number, number>, import('@meshflow/core').MeshPath, Omit<{
    label: string;
    name: string;
    placeholder?: string;
    disabled: boolean;
    readonly: boolean;
    hidden?: boolean;
    validators?: any;
    theme?: string;
}, "placeholder" | "label" | "name" | "validators"> & {
    type: "group";
    name?: string;
    children: ((Omit<{
        label: string;
        name: string;
        placeholder?: string;
        disabled: boolean;
        readonly: boolean;
        hidden?: boolean;
        validators?: any;
        theme?: string;
    }, "placeholder" | "label" | "name" | "validators"> & /*elided*/ any) | ({
        label: string;
        name: string;
        placeholder?: string;
        disabled: boolean;
        readonly: boolean;
        hidden?: boolean;
        validators?: any;
        theme?: string;
    } & {
        type: "input" | "number";
        required: boolean;
        min?: number;
        maxLength: number;
        value: string | number;
    }) | ({
        label: string;
        name: string;
        placeholder?: string;
        disabled: boolean;
        readonly: boolean;
        hidden?: boolean;
        validators?: any;
        theme?: string;
    } & {
        type: "checkbox";
        description?: string;
        required: boolean;
        value: boolean;
    }) | ({
        label: string;
        name: string;
        placeholder?: string;
        disabled: boolean;
        readonly: boolean;
        hidden?: boolean;
        validators?: any;
        theme?: string;
    } & {
        type: "select";
        required: boolean;
        options: {
            label: string;
            value: any;
        }[];
        value: any;
    }))[];
}, M, never>> & {
    modules: import('@meshflow/core').EngineModules<M & {
        internalModules: {
            internalForm: <T, P extends import('@meshflow/core').MeshPath>(scheduler: ReturnType<typeof import('@meshflow/core').useScheduler>, rootSchema: any) => {
                uiSchema: {
                    hidden?: boolean | undefined;
                    disabled: boolean;
                    readonly: boolean;
                    theme?: string | undefined;
                    type: "group";
                    name?: string | undefined;
                    path: any;
                    dirtySignal: any;
                    uid: number;
                    nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                    dependOn: (cb: (...args: any) => void) => void;
                    children: Array</*elided*/ any | {
                        label: string;
                        name: string;
                        placeholder?: string | undefined;
                        disabled: boolean;
                        readonly: boolean;
                        hidden?: boolean | undefined;
                        validators?: any;
                        theme?: string | undefined;
                        type: "input" | "number";
                        required: boolean;
                        min?: number | undefined;
                        maxLength: number;
                        value: string | number;
                        path: any;
                        dirtySignal: any;
                        uid: number;
                        nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                        dependOn: (cb: (...args: any) => void) => void;
                    } | {
                        label: string;
                        name: string;
                        placeholder?: string | undefined;
                        disabled: boolean;
                        readonly: boolean;
                        hidden?: boolean | undefined;
                        validators?: any;
                        theme?: string | undefined;
                        type: "checkbox";
                        description?: string | undefined;
                        required: boolean;
                        value: boolean;
                        path: any;
                        dirtySignal: any;
                        uid: number;
                        nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                        dependOn: (cb: (...args: any) => void) => void;
                    } | {
                        label: string;
                        name: string;
                        placeholder?: string | undefined;
                        disabled: boolean;
                        readonly: boolean;
                        hidden?: boolean | undefined;
                        validators?: any;
                        theme?: string | undefined;
                        type: "select";
                        required: boolean;
                        options: {
                            label: string;
                            value: any;
                        }[];
                        value: any;
                        path: any;
                        dirtySignal: any;
                        uid: number;
                        nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                        dependOn: (cb: (...args: any) => void) => void;
                    }>;
                } | {
                    label: string;
                    name: string;
                    placeholder?: string | undefined;
                    disabled: boolean;
                    readonly: boolean;
                    hidden?: boolean | undefined;
                    validators?: any;
                    theme?: string | undefined;
                    type: "input" | "number";
                    required: boolean;
                    min?: number | undefined;
                    maxLength: number;
                    value: string | number;
                    path: any;
                    dirtySignal: any;
                    uid: number;
                    nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                    dependOn: (cb: (...args: any) => void) => void;
                } | {
                    label: string;
                    name: string;
                    placeholder?: string | undefined;
                    disabled: boolean;
                    readonly: boolean;
                    hidden?: boolean | undefined;
                    validators?: any;
                    theme?: string | undefined;
                    type: "checkbox";
                    description?: string | undefined;
                    required: boolean;
                    value: boolean;
                    path: any;
                    dirtySignal: any;
                    uid: number;
                    nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                    dependOn: (cb: (...args: any) => void) => void;
                } | {
                    label: string;
                    name: string;
                    placeholder?: string | undefined;
                    disabled: boolean;
                    readonly: boolean;
                    hidden?: boolean | undefined;
                    validators?: any;
                    theme?: string | undefined;
                    type: "select";
                    required: boolean;
                    options: {
                        label: string;
                        value: any;
                    }[];
                    value: any;
                    path: any;
                    dirtySignal: any;
                    uid: number;
                    nodeBucket: Record<string, import('@meshflow/core').SchemaBucket<any>>;
                    dependOn: (cb: (...args: any) => void) => void;
                };
                GetFormData: () => any;
            };
            schemaValidators: <P extends import('@meshflow/core').MeshPath>(Finder: (path: P) => any) => {
                SetValidators: (path: P, options: {
                    logic: (val: any, GetByPath: any) => any;
                    condition: (data: any) => boolean;
                }) => void;
            };
        };
    }, import('@meshflow/core').MeshPath>;
} & {
    plugins: {
        SetTrace: (myPath: import('@meshflow/core').MeshPath, onUpdate: (newStatus: "idle" | "pending" | "calculating" | "calculated" | "error" | "canceled") => void) => {
            cancel: () => void;
        };
    };
    define: (rules: Record<string, FromDescriptor>) => void;
    graph: MeshGraph;
    setRule: (...args: any[]) => void;
    setRules: (...args: any[]) => void;
    entangle: (...args: any[]) => any;
}, "define"> & {
    define: (rules: MeshDefineRules<S>) => void;
};
export { deleteEngine, from };
export type { MeshFormSchema, FromDescriptor, MeshGraph };
